package com.example.schoolattendance

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Student(
    var name: String,
    var phone: String,
    var className: String,
    var attendance: String = "Not marked",
    var marks: String = "",
    var total: String = "100"
)

class MainActivity : Activity() {
    private val students = mutableListOf<Student>()
    private lateinit var root: LinearLayout
    private lateinit var classSpinner: Spinner
    private lateinit var nameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var marksInput: EditText
    private lateinit var totalInput: EditText
    private lateinit var testInput: EditText
    private lateinit var listBox: LinearLayout
    private val classes = (1..10).map { "Class $it" } + listOf("Nursery", "KG")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadStudents()
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "School Attendance & Results"
            textSize = 24f
            setTextColor(Color.rgb(22, 59, 104))
            setPadding(0, 0, 0, 10)
        })
        root.addView(TextView(this).apply {
            text = "Free offline student record app"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        classSpinner = Spinner(this)
        classSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, classes)
        root.addView(label("Select class"))
        root.addView(classSpinner)

        root.addView(label("Student full name"))
        nameInput = EditText(this).apply { hint = "e.g. Ali Ahmed" }
        root.addView(nameInput)

        root.addView(label("Parent WhatsApp number (with country code)"))
        phoneInput = EditText(this).apply {
            hint = "e.g. 923001234567"
            inputType = 3
        }
        root.addView(phoneInput)

        val addButton = Button(this).apply {
            text = "Add student"
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                if (name.isBlank()) {
                    toast("Please enter the student's name")
                    return@setOnClickListener
                }
                students.add(Student(name, phoneInput.text.toString().trim(), classSpinner.selectedItem.toString()))
                saveStudents()
                nameInput.setText("")
                phoneInput.setText("")
                render()
                toast("Student saved on this phone")
            }
        }
        root.addView(addButton)

        root.addView(label("Test name"))
        testInput = EditText(this).apply { hint = "e.g. English monthly test"; setText("Monthly Test") }
        root.addView(testInput)
        root.addView(label("Obtained marks and total marks are entered per student below."))

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        refreshList()
        root.addView(TextView(this).apply {
            text = "Note: records are stored locally on this phone. Back up/export is not included in this starter version."
            textSize = 12f
            setPadding(0, 18, 0, 0)
            setTextColor(Color.DKGRAY)
        })
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val selectedClass = classSpinner.selectedItem?.toString() ?: classes.first()
        val filtered = students.filter { it.className == selectedClass }
        listBox.addView(label("$selectedClass — ${filtered.size} students"))
        if (filtered.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "No students yet. Add a student above."
                setPadding(0, 12, 0, 12)
            })
        }
        filtered.forEach { student ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(Color.WHITE)
            }
            val title = TextView(this).apply {
                text = student.name
                textSize = 18f
                setTextColor(Color.rgb(22, 59, 104))
            }
            card.addView(title)
            card.addView(TextView(this).apply { text = "Parent: ${student.phone.ifBlank { "not added" }}" })
            val attendanceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf("Present", "Absent", "Leave").forEach { status ->
                attendanceRow.addView(Button(this@MainActivity).apply {
                    text = status
                    textSize = 10f
                    setOnClickListener {
                        student.attendance = status
                        saveStudents()
                        refreshList()
                    }
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            card.addView(attendanceRow)
            card.addView(TextView(this).apply { text = "Attendance: ${student.attendance}" })

            val markRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val obtained = EditText(this@MainActivity).apply {
                hint = "Marks"
                inputType = 2
                setText(student.marks)
            }
            val total = EditText(this@MainActivity).apply {
                hint = "Total"
                inputType = 2
                setText(student.total)
            }
            markRow.addView(obtained, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            markRow.addView(total, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(markRow)

            card.addView(Button(this).apply {
                text = "Save marks"
                setOnClickListener {
                    student.marks = obtained.text.toString().trim()
                    student.total = total.text.toString().trim().ifBlank { "100" }
                    saveStudents()
                    val t = student.total.toDoubleOrNull()
                    val m = student.marks.toDoubleOrNull()
                    if (t != null && m != null && t > 0 && m >= 0 && m <= t) {
                        toast("Saved: ${"%.1f".format(m / t * 100)}%")
                    } else toast("Marks saved. Check marks and total for percentage.")
                }
            })
            card.addView(Button(this).apply {
                text = "Prepare WhatsApp message"
                setOnClickListener { shareWhatsApp(student) }
            })
            card.addView(Button(this).apply {
                text = "Delete student"
                setOnClickListener {
                    students.remove(student)
                    saveStudents()
                    refreshList()
                }
            })
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 10, 0, 10)
            listBox.addView(card, lp)
        }
        classSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (::listBox.isInitialized) refreshListForClassOnly()
            }
        }
    }

    private fun refreshListForClassOnly() {
        // Re-render cards without resetting student data fields.
        val selectedClass = classSpinner.selectedItem?.toString() ?: classes.first()
        listBox.removeAllViews()
        val filtered = students.filter { it.className == selectedClass }
        listBox.addView(label("$selectedClass — ${filtered.size} students"))
        filtered.forEach { s ->
            listBox.addView(TextView(this).apply {
                text = "${s.name} | Attendance: ${s.attendance} | Marks: ${s.marks.ifBlank { "-" }}/${s.total}"
                textSize = 15f
                setPadding(0, 10, 0, 10)
            })
            listBox.addView(Button(this).apply {
                text = "Open WhatsApp message for ${s.name}"
                setOnClickListener { shareWhatsApp(s) }
            })
        }
    }

    private fun shareWhatsApp(s: Student) {
        if (s.phone.isBlank()) {
            toast("Add the parent's WhatsApp number first")
            return
        }
        val total = s.total.toDoubleOrNull()
        val marks = s.marks.toDoubleOrNull()
        val result = if (total != null && marks != null && total > 0 && marks >= 0 && marks <= total)
            "Test: ${testInput.text}\nMarks: ${s.marks}/${s.total}\nPercentage: ${"%.1f".format(marks / total * 100)}%"
        else "Attendance: ${s.attendance}"
        val message = "Assalam-o-Alaikum. School update for ${s.name} (${s.className}):\n$result"
        try {
            val uri = android.net.Uri.parse("https://wa.me/${s.phone.filter { it.isDigit() }}?text=${android.net.Uri.encode(message)}")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            toast("Could not open WhatsApp. Check the number and WhatsApp installation.")
        }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(45, 55, 72))
        setPadding(0, 14, 0, 4)
    }

    private fun saveStudents() {
        val array = JSONArray()
        students.forEach { s ->
            array.put(JSONObject().apply {
                put("name", s.name); put("phone", s.phone); put("className", s.className)
                put("attendance", s.attendance); put("marks", s.marks); put("total", s.total)
            })
        }
        getSharedPreferences("school_data", MODE_PRIVATE).edit().putString("students", array.toString()).apply()
    }

    private fun loadStudents() {
        val raw = getSharedPreferences("school_data", MODE_PRIVATE).getString("students", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                students.add(Student(o.optString("name"), o.optString("phone"), o.optString("className", "Class 1"),
                    o.optString("attendance", "Not marked"), o.optString("marks"), o.optString("total", "100")))
            }
        } catch (_: Exception) {}
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
