# School Attendance & Results — Android starter project

یہ ایک مفت Android Studio starter project ہے۔ اس میں:
- Class 1–10، Nursery اور KG کے لیے class selection
- طالب علم کا نام اور والدین کا WhatsApp نمبر محفوظ کرنا
- روزانہ Present / Absent / Leave نشان زد کرنا
- ٹیسٹ کے نمبر محفوظ کرنا اور percentage نکالنا
- WhatsApp میں پیغام کھولنا (پیغام خودکار طور پر پس منظر میں نہیں بھیجتا)
- ڈیٹا اسی موبائل پر SharedPreferences میں محفوظ ہوتا ہے

## APK کیسے بنائیں
1. کمپیوٹر پر Android Studio کا مفت ورژن انسٹال کریں۔
2. Android Studio میں **Open** منتخب کریں اور اس ZIP کو extract کرنے کے بعد `SchoolAttendanceApp` فولڈر کھولیں۔
3. Gradle sync مکمل ہونے دیں۔
4. مینو سے **Build > Build APK(s)** منتخب کریں۔
5. APK عام طور پر `app/build/outputs/apk/debug/app-debug.apk` میں ملے گی۔
6. APK اپنے Android فون میں منتقل کریں اور صرف اپنی بنائی ہوئی/قابلِ اعتماد APK انسٹال کریں۔

## اہم حدود
- یہ starter project ہے، مکمل طور پر test شدہ/production-ready school system نہیں۔
- APK بنانے کے لیے کمپیوٹر پر Android Studio درکار ہے؛ یہ ZIP خود APK نہیں ہے۔
- WhatsApp message کھولتا ہے تاکہ استاد بھیجنے سے پہلے جائزہ لے سکے؛ یہ خودکار bulk sending نہیں کرتا۔
- ڈیٹا صرف اسی فون پر ہے۔ فون reset یا app data clear ہونے پر ریکارڈ ضائع ہو سکتا ہے۔
- والدین کے حقیقی فون نمبرز اور طلبہ کا ذاتی ڈیٹا صرف اجازت کے ساتھ استعمال کریں۔
